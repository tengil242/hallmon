# [Dashing](https://github.com/dashing-io/dashing/wiki)

Dashing is a Sinatra based framework that lets you build beautiful dashboards. It looks especially great on TVs.

[Check out wiki](https://github.com/dashing-io/dashing/wiki).

Note: This is a fork of the original Dashing project. The original is no longer being maintained, hence this version. Read about it [here](https://github.com/Shopify/dashing/issues/711).

# License
Distributed under the [MIT license](MIT-LICENSE)
